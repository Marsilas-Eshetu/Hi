# Web tech

Css and bootstrap note

CSS NOTES

- CSS is the language we use to style an HTML document.
CSS describes how HTML elements should be displayed

CSS Syntax

A CSS rule consists of a selector and a declaration block.

p {
color: red;
text-align: center;
}

The selector(p) points to the HTML element you want to style.
The declaration block contains one or more declarations separated by semicolons.
Each declaration includes a CSS property name and a value, separated by a colon.

CSS Backgrounds

The CSS background properties are used to add background effects for elements.
background-color

background-image

background-repeat

background-attachment

background-position

background (shorthand property)

CSS Margins

The CSS margin properties are used to create space around elements, outside of any defined borders.
Note:Negative values are allowed.

CSS Padding

The CSS padding properties are used to generate space around an element's content, inside of any defined borders.
Note: Negative values are not allowed.

CSS Icons

The simplest way to add an icon to your HTML page, is with an icon library
Add the name of the specified icon class to any inline HTML element (like <i> or <span>).

CSS Lists

The CSS list properties allow you to:

Set different list item markers for ordered lists

Set different list item markers for unordered lists

Set an image as the list item marker

Add background colors to lists and list items

CSS Layout - Horizontal & Vertical Align

To horizontally center a block element (like <div>), use margin: auto;
Setting the width of the element will prevent it from stretching out to the edges of its container.
The element will then take up the specified width, and the remaining space will be split equally between the two margins:
Note: Center aligning has no effect if the width property is not set (or set to 100%).

Center align text-To just center the text inside an element, use text-align: center;

CSS Height, Width and Max-width

The CSS height and width properties are used to set the height and width of an element.
The CSS max-width property is used to set the maximum width of an element.
The height and width properties do not include padding, borders, or margins. It sets the height/width of the area inside the padding, border, and margin of the element.
Example

Set the height and width of a <div> element:

div {
height:200px;
width: 50%;
background-color: powderblue;
}

CSS Navigation Bar

Having easy-to-use navigation is important for any web site.
With CSS you can transform boring HTML menus into good-looking navigation bars.

Navigation Bar = List of Links

A navigation bar needs standard HTML as a base.
A navigation bar is basically a list of links, so using the <ul> and <li> elements makes perfect sense

CSS Counters

CSS counters are "variables" maintained by CSS whose values can be incremented by CSS rules (to track how many times they are used). Counters let you adjust the appearance of content based on its placement in the document.

Automatic Numbering With Counters
CSS counters are like "variables". The variable values can be incremented by CSS rules (which will track how many times they are used).
To work with CSS counters we will use the following properties:
•	counter-reset - Creates or resets a counter
•	counter-increment - Increments a counter value
•	content - Inserts generated content
•	counter() or counters() function - Adds the value of a counter to an element
To use a CSS counter, it must first be created with counter-reset.

Example
body {
counter-reset: section;
}

h2::before {
counter-increment: section;
content: "Section " counter(section) ": ";
}

Bootstrap
•	Bootstrap is a free front-end framework for faster and easier web development
•	Bootstrap includes HTML and CSS based design templates for typography, forms, buttons, tables, navigation, modals, image carousels and many other, as well as optional JavaScript plugins
•	Bootstrap also gives you the ability to easily create responsive designs
What is Responsive Web Design?

Responsive web design is about creating web sites which automatically adjust themselves to look good on all devices, from small phones to large desktops.
Advantages of Bootstrap:
•	Easy to use: Anybody with just basic knowledge of HTML and CSS can start using Bootstrap
•	Responsive features: Bootstrap's responsive CSS adjusts to phones, tablets, and desktops
•	Mobile-first approach: In Bootstrap 3, mobile-first styles are part of the core framework
•	Browser compatibility: Bootstrap is compatible with all modern browsers (Chrome, Firefox, Internet Explorer, Edge, Safari, and Opera)
Bootstrap Example
<div class="jumbotron text-center">
<h1>My First Bootstrap Page</h1>
<p>Resize this responsive page to see the effect!</p>
</div>

<div class="container">
<div class="row">
<div class="col-sm-4">
<h3>Column 1</h3>
<p>Lorem ipsum dolor..</p>
</div>
<div class="col-sm-4">
<h3>Column 2</h3>
<p>Lorem ipsum dolor..</p>
</div>
<div class="col-sm-4">
<h3>Column 3</h3>
<p>Lorem ipsum dolor..</p>
</div>
</div>
</div>
Bootstrap Grids
Bootstrap Grid System
Bootstrap's grid system allows up to 12 columns across the page.
If you do not want to use all 12 columns individually, you can group the columns together to create wider columns:
Bootstrap's grid system is responsive, and the columns will re-arrange automatically depending on the screen size.

Grid Classes
The Bootstrap grid system has four classes:
•	xs (for phones - screens less than 768px wide)
•	sm (for tablets - screens equal to or greater than 768px wide)
•	md (for small laptops - screens equal to or greater than 992px wide)
•	lg (for laptops and desktops - screens equal to or greater than 1200px wide)

Bootstrap vs. Browser Defaults
In this chapter, we will look at some HTML elements that will be styled a little bit differently by Bootstrap than browser defaults.

<h1> - <h6>
By default, Bootstrap will style the HTML headings (<h1> to <h6>) in the following way:
EXAMPLE
h1 Bootstrap heading (36px)
h2 Bootstrap heading (30px)
h3 Bootstrap heading (24px)
h4 Bootstrap heading (18px)
h5 Bootstrap heading (14px)
h6 Bootstrap heading (12px)
<mark>
Bootstrap will style the HTML <mark> element in the following way:
To highlight a text
<abbr>
Bootstrap will style the HTML <abbr> element in the following way:
EXAMPLE
The WHO was founded in 1948.
<dl>
Bootstrap will style the HTML <dl> element in the following way:
EXAMPLE
Coffee

- black hot drink
Milk
- white cold drink
<pre>
Bootstrap will style the HTML <pre> element in the following way:
EXAMPLE
Text in a pre element
is displayed in a fixed-width
font, and it preserves
both spaces and
line breaks.
Contextual Colors and Backgrounds
Bootstrap also has some contextual classes that can be used to provide "meaning through colors".
The classes for text colors are:.text-muted, .text-primary, .text-success, .text-info, .text-warning, and .text-danger:
The classes for background colors are:.bg-primary, .bg-success, .bg-info, .bg-warning, and .bg-danger
Bootstrap Basic Table
A basic Bootstrap table has a light padding and only horizontal dividers.
The .table class adds basic styling to a table
Striped Rows
The .table-striped class adds zebra-stripes to a table:
Hover Rows
The .table-hover class adds a hover effect (grey background color) on table rows:
Responsive Tables
The .table-responsive class creates a responsive table. The table will then scroll horizontally on small devices (under 768px). When viewing on anything larger than 768px wide, there is no difference
Responsive Images
Images come in all sizes. So do screens. Responsive images automatically adjust to fit the size of the screen.
Example
<img class="img-responsive" src="img_chania.jpg" alt="Chania">
Basic Pagination
If you have a web site with lots of pages, you may wish to add some sort of pagination to each page.
To create a basic pagination, add the .pagination class to an <ul> element:
Active State
The active state shows what is the current page
Add class .active to let the user know which page he/she is on
Basic Collapsible
Collapsibles are useful when you want to hide and show large amount of content:
Navigation Bars
A navigation bar is a navigation header that is placed at the top of the page:
With Bootstrap, a navigation bar can extend or collapse, depending on the screen size.
A standard navigation bar is created with <nav class="navbar navbar-default">.
Bootstrap Form Layouts
Bootstrap provides three types of form layouts:
•	Vertical form (this is default)
•	Horizontal form
•	Inline form
Standard rules for all three form layouts:
•	Wrap labels and form controls in <div class="form-group"> (needed for optimum spacing)
•	Add class .form-control to all textual <input>, <textarea>, and <select> elements
Bootstrap supports the following form controls:
•	input
•	textarea
•	checkbox
•	radio
•	select
Bootstrap Input
Bootstrap supports all the HTML5 input types: text, password, datetime, datetime-local, date, month, time, week, number, email, url, search, tel, and color.
Note: Inputs will NOT be fully styled if their type is not properly declared!